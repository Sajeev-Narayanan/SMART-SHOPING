package com.example.shopmee;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class login extends AppCompatActivity implements View.OnClickListener {

    EditText eduname,edpassword;
    Button btlogin;
    TextView reg;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        eduname = (EditText) findViewById(R.id.editText);
        edpassword = (EditText) findViewById(R.id.editText2);
        reg = (TextView) findViewById(R.id.textView79);
        btlogin = (Button) findViewById(R.id.mylogin);
        btlogin.setOnClickListener(this);
        reg.setOnClickListener(this);

        eduname.setText("likhil@gmail.com");
        edpassword.setText("aa");


    }

    @Override
    public void onClick(View view) {

        if(view==btlogin){



            SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            String hu = sh.getString("ip", "");
            String url = "http://" + hu + ":5005/amd_login";

//            Toast.makeText(this, "fdhcd"+url, Toast.LENGTH_SHORT).show();



            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
//                              Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                            // response
                            try {
                                JSONObject jsonObj = new JSONObject(response);
                                if (jsonObj.getString("status").equalsIgnoreCase("ok")) {


//
                                    String type=jsonObj.getString("type");
                                    String id=jsonObj.getString("id");

                                    SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                                    SharedPreferences.Editor ed=sh.edit();
                                    ed.putString("lid",id);
                                    ed.commit();
                                    if (type.equalsIgnoreCase("user"))
                                    {
                                        Intent ik=new Intent(getApplicationContext(),LocationService.class);
                                        startService(ik);
                                        Intent ij=new Intent(getApplicationContext(),userhome.class);
                                        startActivity(ij);
                                    }
                                    if (type.equalsIgnoreCase("delivery_boy")){
                                        Intent ik=new Intent(getApplicationContext(),LocationService.class);
                                        startService(ik);
                                        Intent ij=new Intent(getApplicationContext(),delivery_boy_userhome.class);
                                        startActivity(ij);
                                    }










                                }


                                // }
                                else {
                                    Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                                }

                            }    catch (Exception e) {
                                Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("username",eduname.getText().toString());
                params.put("pass",edpassword.getText().toString());

                    return params;
                }
            };

            int MY_SOCKET_TIMEOUT_MS=100000;

            postRequest.setRetryPolicy(new DefaultRetryPolicy(
                    MY_SOCKET_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            requestQueue.add(postRequest);


        }

        if(view==reg){

            Intent ins= new Intent(getApplicationContext(),Registration.class);
            startActivity(ins);
        }

    }
}